### Hexlet tests and linter status:
[![Actions Status](https://github.com/mannayamasha/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/mannayamasha/python-project-49/actions)
<a href="https://codeclimate.com/github/ma<a href="https://codeclimate.com/github/mannayamasha/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/f7b7da33cd381202da57/maintainability" /></a>
