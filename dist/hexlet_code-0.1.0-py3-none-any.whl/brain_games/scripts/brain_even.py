#!/usr/bin/env python3

import prompt

from brain_games.parity_check import parity_check


def main():
    parity_check()


if __name__ == '__main__':
    main()
